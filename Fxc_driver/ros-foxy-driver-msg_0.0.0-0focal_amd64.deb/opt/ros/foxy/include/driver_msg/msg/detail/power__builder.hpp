// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Power.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__POWER__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__POWER__BUILDER_HPP_

#include "driver_msg/msg/detail/power__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Power_soc
{
public:
  explicit Init_Power_soc(::driver_msg::msg::Power & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Power soc(::driver_msg::msg::Power::_soc_type arg)
  {
    msg_.soc = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Power msg_;
};

class Init_Power_curruntma
{
public:
  explicit Init_Power_curruntma(::driver_msg::msg::Power & msg)
  : msg_(msg)
  {}
  Init_Power_soc curruntma(::driver_msg::msg::Power::_curruntma_type arg)
  {
    msg_.curruntma = std::move(arg);
    return Init_Power_soc(msg_);
  }

private:
  ::driver_msg::msg::Power msg_;
};

class Init_Power_voltagemv
{
public:
  explicit Init_Power_voltagemv(::driver_msg::msg::Power & msg)
  : msg_(msg)
  {}
  Init_Power_curruntma voltagemv(::driver_msg::msg::Power::_voltagemv_type arg)
  {
    msg_.voltagemv = std::move(arg);
    return Init_Power_curruntma(msg_);
  }

private:
  ::driver_msg::msg::Power msg_;
};

class Init_Power_header
{
public:
  Init_Power_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Power_voltagemv header(::driver_msg::msg::Power::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Power_voltagemv(msg_);
  }

private:
  ::driver_msg::msg::Power msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Power>()
{
  return driver_msg::msg::builder::Init_Power_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__POWER__BUILDER_HPP_
