// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__PSENSOR_HPP_
#define DRIVER_MSG__MSG__PSENSOR_HPP_

#include "driver_msg/msg/detail/psensor__struct.hpp"
#include "driver_msg/msg/detail/psensor__builder.hpp"
#include "driver_msg/msg/detail/psensor__traits.hpp"

#endif  // DRIVER_MSG__MSG__PSENSOR_HPP_
