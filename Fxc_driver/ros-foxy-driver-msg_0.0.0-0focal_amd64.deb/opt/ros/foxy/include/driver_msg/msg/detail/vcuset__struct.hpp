// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from driver_msg:msg/Vcuset.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSET__STRUCT_HPP_
#define DRIVER_MSG__MSG__DETAIL__VCUSET__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__driver_msg__msg__Vcuset __attribute__((deprecated))
#else
# define DEPRECATED__driver_msg__msg__Vcuset __declspec(deprecated)
#endif

namespace driver_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Vcuset_
{
  using Type = Vcuset_<ContainerAllocator>;

  explicit Vcuset_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sleep_mcu = false;
      this->reset_imu = false;
      this->reset_odom = false;
      this->reset_lifter = false;
      this->lighting = 0;
      this->enable_safety_zone = false;
      this->poweroff_roscube = false;
    }
  }

  explicit Vcuset_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sleep_mcu = false;
      this->reset_imu = false;
      this->reset_odom = false;
      this->reset_lifter = false;
      this->lighting = 0;
      this->enable_safety_zone = false;
      this->poweroff_roscube = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _sleep_mcu_type =
    bool;
  _sleep_mcu_type sleep_mcu;
  using _reset_imu_type =
    bool;
  _reset_imu_type reset_imu;
  using _reset_odom_type =
    bool;
  _reset_odom_type reset_odom;
  using _reset_lifter_type =
    bool;
  _reset_lifter_type reset_lifter;
  using _lighting_type =
    int16_t;
  _lighting_type lighting;
  using _enable_safety_zone_type =
    bool;
  _enable_safety_zone_type enable_safety_zone;
  using _poweroff_roscube_type =
    bool;
  _poweroff_roscube_type poweroff_roscube;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__sleep_mcu(
    const bool & _arg)
  {
    this->sleep_mcu = _arg;
    return *this;
  }
  Type & set__reset_imu(
    const bool & _arg)
  {
    this->reset_imu = _arg;
    return *this;
  }
  Type & set__reset_odom(
    const bool & _arg)
  {
    this->reset_odom = _arg;
    return *this;
  }
  Type & set__reset_lifter(
    const bool & _arg)
  {
    this->reset_lifter = _arg;
    return *this;
  }
  Type & set__lighting(
    const int16_t & _arg)
  {
    this->lighting = _arg;
    return *this;
  }
  Type & set__enable_safety_zone(
    const bool & _arg)
  {
    this->enable_safety_zone = _arg;
    return *this;
  }
  Type & set__poweroff_roscube(
    const bool & _arg)
  {
    this->poweroff_roscube = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    driver_msg::msg::Vcuset_<ContainerAllocator> *;
  using ConstRawPtr =
    const driver_msg::msg::Vcuset_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<driver_msg::msg::Vcuset_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<driver_msg::msg::Vcuset_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Vcuset_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Vcuset_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Vcuset_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Vcuset_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<driver_msg::msg::Vcuset_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<driver_msg::msg::Vcuset_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__driver_msg__msg__Vcuset
    std::shared_ptr<driver_msg::msg::Vcuset_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__driver_msg__msg__Vcuset
    std::shared_ptr<driver_msg::msg::Vcuset_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Vcuset_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->sleep_mcu != other.sleep_mcu) {
      return false;
    }
    if (this->reset_imu != other.reset_imu) {
      return false;
    }
    if (this->reset_odom != other.reset_odom) {
      return false;
    }
    if (this->reset_lifter != other.reset_lifter) {
      return false;
    }
    if (this->lighting != other.lighting) {
      return false;
    }
    if (this->enable_safety_zone != other.enable_safety_zone) {
      return false;
    }
    if (this->poweroff_roscube != other.poweroff_roscube) {
      return false;
    }
    return true;
  }
  bool operator!=(const Vcuset_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Vcuset_

// alias to use template instance with default allocator
using Vcuset =
  driver_msg::msg::Vcuset_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSET__STRUCT_HPP_
