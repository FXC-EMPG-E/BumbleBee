// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from driver_msg:msg/Lifter.idl
// generated code does not contain a copyright notice
#include "driver_msg/msg/detail/lifter__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
driver_msg__msg__Lifter__init(driver_msg__msg__Lifter * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    driver_msg__msg__Lifter__fini(msg);
    return false;
  }
  // position
  // rpm
  return true;
}

void
driver_msg__msg__Lifter__fini(driver_msg__msg__Lifter * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // position
  // rpm
}

driver_msg__msg__Lifter *
driver_msg__msg__Lifter__create()
{
  driver_msg__msg__Lifter * msg = (driver_msg__msg__Lifter *)malloc(sizeof(driver_msg__msg__Lifter));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(driver_msg__msg__Lifter));
  bool success = driver_msg__msg__Lifter__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
driver_msg__msg__Lifter__destroy(driver_msg__msg__Lifter * msg)
{
  if (msg) {
    driver_msg__msg__Lifter__fini(msg);
  }
  free(msg);
}


bool
driver_msg__msg__Lifter__Sequence__init(driver_msg__msg__Lifter__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  driver_msg__msg__Lifter * data = NULL;
  if (size) {
    data = (driver_msg__msg__Lifter *)calloc(size, sizeof(driver_msg__msg__Lifter));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = driver_msg__msg__Lifter__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        driver_msg__msg__Lifter__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
driver_msg__msg__Lifter__Sequence__fini(driver_msg__msg__Lifter__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      driver_msg__msg__Lifter__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

driver_msg__msg__Lifter__Sequence *
driver_msg__msg__Lifter__Sequence__create(size_t size)
{
  driver_msg__msg__Lifter__Sequence * array = (driver_msg__msg__Lifter__Sequence *)malloc(sizeof(driver_msg__msg__Lifter__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = driver_msg__msg__Lifter__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
driver_msg__msg__Lifter__Sequence__destroy(driver_msg__msg__Lifter__Sequence * array)
{
  if (array) {
    driver_msg__msg__Lifter__Sequence__fini(array);
  }
  free(array);
}
