// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__LIDAR__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__LIDAR__BUILDER_HPP_

#include "driver_msg/msg/detail/lidar__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Lidar_rear_yellowzone
{
public:
  explicit Init_Lidar_rear_yellowzone(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Lidar rear_yellowzone(::driver_msg::msg::Lidar::_rear_yellowzone_type arg)
  {
    msg_.rear_yellowzone = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_rear_redzone
{
public:
  explicit Init_Lidar_rear_redzone(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_rear_yellowzone rear_redzone(::driver_msg::msg::Lidar::_rear_redzone_type arg)
  {
    msg_.rear_redzone = std::move(arg);
    return Init_Lidar_rear_yellowzone(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_rear_field
{
public:
  explicit Init_Lidar_rear_field(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_rear_redzone rear_field(::driver_msg::msg::Lidar::_rear_field_type arg)
  {
    msg_.rear_field = std::move(arg);
    return Init_Lidar_rear_redzone(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_front_yellowzone
{
public:
  explicit Init_Lidar_front_yellowzone(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_rear_field front_yellowzone(::driver_msg::msg::Lidar::_front_yellowzone_type arg)
  {
    msg_.front_yellowzone = std::move(arg);
    return Init_Lidar_rear_field(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_front_redzone
{
public:
  explicit Init_Lidar_front_redzone(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_front_yellowzone front_redzone(::driver_msg::msg::Lidar::_front_redzone_type arg)
  {
    msg_.front_redzone = std::move(arg);
    return Init_Lidar_front_yellowzone(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_front_field
{
public:
  explicit Init_Lidar_front_field(::driver_msg::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_front_redzone front_field(::driver_msg::msg::Lidar::_front_field_type arg)
  {
    msg_.front_field = std::move(arg);
    return Init_Lidar_front_redzone(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

class Init_Lidar_header
{
public:
  Init_Lidar_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Lidar_front_field header(::driver_msg::msg::Lidar::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Lidar_front_field(msg_);
  }

private:
  ::driver_msg::msg::Lidar msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Lidar>()
{
  return driver_msg::msg::builder::Init_Lidar_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__LIDAR__BUILDER_HPP_
