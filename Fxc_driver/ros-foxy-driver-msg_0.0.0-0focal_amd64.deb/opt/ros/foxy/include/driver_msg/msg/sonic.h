// generated from rosidl_generator_c/resource/idl.h.em
// with input from driver_msg:msg/Sonic.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__SONIC_H_
#define DRIVER_MSG__MSG__SONIC_H_

#include "driver_msg/msg/detail/sonic__struct.h"
#include "driver_msg/msg/detail/sonic__functions.h"
#include "driver_msg/msg/detail/sonic__type_support.h"

#endif  // DRIVER_MSG__MSG__SONIC_H_
