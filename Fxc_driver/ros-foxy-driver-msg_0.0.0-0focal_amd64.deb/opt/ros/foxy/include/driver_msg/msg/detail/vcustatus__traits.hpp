// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from driver_msg:msg/Vcustatus.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSTATUS__TRAITS_HPP_
#define DRIVER_MSG__MSG__DETAIL__VCUSTATUS__TRAITS_HPP_

#include "driver_msg/msg/detail/vcustatus__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<driver_msg::msg::Vcustatus>()
{
  return "driver_msg::msg::Vcustatus";
}

template<>
inline const char * name<driver_msg::msg::Vcustatus>()
{
  return "driver_msg/msg/Vcustatus";
}

template<>
struct has_fixed_size<driver_msg::msg::Vcustatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<driver_msg::msg::Vcustatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<driver_msg::msg::Vcustatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSTATUS__TRAITS_HPP_
