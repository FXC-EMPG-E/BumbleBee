// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Sonic.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__SONIC__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__SONIC__BUILDER_HPP_

#include "driver_msg/msg/detail/sonic__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Sonic_frontright
{
public:
  explicit Init_Sonic_frontright(::driver_msg::msg::Sonic & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Sonic frontright(::driver_msg::msg::Sonic::_frontright_type arg)
  {
    msg_.frontright = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Sonic msg_;
};

class Init_Sonic_frontleft
{
public:
  explicit Init_Sonic_frontleft(::driver_msg::msg::Sonic & msg)
  : msg_(msg)
  {}
  Init_Sonic_frontright frontleft(::driver_msg::msg::Sonic::_frontleft_type arg)
  {
    msg_.frontleft = std::move(arg);
    return Init_Sonic_frontright(msg_);
  }

private:
  ::driver_msg::msg::Sonic msg_;
};

class Init_Sonic_header
{
public:
  Init_Sonic_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Sonic_frontleft header(::driver_msg::msg::Sonic::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Sonic_frontleft(msg_);
  }

private:
  ::driver_msg::msg::Sonic msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Sonic>()
{
  return driver_msg::msg::builder::Init_Sonic_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__SONIC__BUILDER_HPP_
