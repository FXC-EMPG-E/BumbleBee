// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__CLIFF_HPP_
#define DRIVER_MSG__MSG__CLIFF_HPP_

#include "driver_msg/msg/detail/cliff__struct.hpp"
#include "driver_msg/msg/detail/cliff__builder.hpp"
#include "driver_msg/msg/detail/cliff__traits.hpp"

#endif  // DRIVER_MSG__MSG__CLIFF_HPP_
