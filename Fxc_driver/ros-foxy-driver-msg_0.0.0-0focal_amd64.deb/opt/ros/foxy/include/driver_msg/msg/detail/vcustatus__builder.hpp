// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Vcustatus.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSTATUS__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__VCUSTATUS__BUILDER_HPP_

#include "driver_msg/msg/detail/vcustatus__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Vcustatus_btnholdtorun
{
public:
  explicit Init_Vcustatus_btnholdtorun(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Vcustatus btnholdtorun(::driver_msg::msg::Vcustatus::_btnholdtorun_type arg)
  {
    msg_.btnholdtorun = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_btnpower
{
public:
  explicit Init_Vcustatus_btnpower(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_btnholdtorun btnpower(::driver_msg::msg::Vcustatus::_btnpower_type arg)
  {
    msg_.btnpower = std::move(arg);
    return Init_Vcustatus_btnholdtorun(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_btnestop
{
public:
  explicit Init_Vcustatus_btnestop(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_btnpower btnestop(::driver_msg::msg::Vcustatus::_btnestop_type arg)
  {
    msg_.btnestop = std::move(arg);
    return Init_Vcustatus_btnpower(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_btnreset
{
public:
  explicit Init_Vcustatus_btnreset(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_btnestop btnreset(::driver_msg::msg::Vcustatus::_btnreset_type arg)
  {
    msg_.btnreset = std::move(arg);
    return Init_Vcustatus_btnestop(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_isestop
{
public:
  explicit Init_Vcustatus_isestop(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_btnreset isestop(::driver_msg::msg::Vcustatus::_isestop_type arg)
  {
    msg_.isestop = std::move(arg);
    return Init_Vcustatus_btnreset(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_releasemotor
{
public:
  explicit Init_Vcustatus_releasemotor(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_isestop releasemotor(::driver_msg::msg::Vcustatus::_releasemotor_type arg)
  {
    msg_.releasemotor = std::move(arg);
    return Init_Vcustatus_isestop(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_automode
{
public:
  explicit Init_Vcustatus_automode(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_releasemotor automode(::driver_msg::msg::Vcustatus::_automode_type arg)
  {
    msg_.automode = std::move(arg);
    return Init_Vcustatus_releasemotor(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_liftercnntstats
{
public:
  explicit Init_Vcustatus_liftercnntstats(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_automode liftercnntstats(::driver_msg::msg::Vcustatus::_liftercnntstats_type arg)
  {
    msg_.liftercnntstats = std::move(arg);
    return Init_Vcustatus_automode(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_safetycnntstats
{
public:
  explicit Init_Vcustatus_safetycnntstats(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_liftercnntstats safetycnntstats(::driver_msg::msg::Vcustatus::_safetycnntstats_type arg)
  {
    msg_.safetycnntstats = std::move(arg);
    return Init_Vcustatus_liftercnntstats(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_motorcnntstats
{
public:
  explicit Init_Vcustatus_motorcnntstats(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_safetycnntstats motorcnntstats(::driver_msg::msg::Vcustatus::_motorcnntstats_type arg)
  {
    msg_.motorcnntstats = std::move(arg);
    return Init_Vcustatus_safetycnntstats(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_mainboradcnntstats
{
public:
  explicit Init_Vcustatus_mainboradcnntstats(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_motorcnntstats mainboradcnntstats(::driver_msg::msg::Vcustatus::_mainboradcnntstats_type arg)
  {
    msg_.mainboradcnntstats = std::move(arg);
    return Init_Vcustatus_motorcnntstats(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_ros_fw_version
{
public:
  explicit Init_Vcustatus_ros_fw_version(::driver_msg::msg::Vcustatus & msg)
  : msg_(msg)
  {}
  Init_Vcustatus_mainboradcnntstats ros_fw_version(::driver_msg::msg::Vcustatus::_ros_fw_version_type arg)
  {
    msg_.ros_fw_version = std::move(arg);
    return Init_Vcustatus_mainboradcnntstats(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

class Init_Vcustatus_header
{
public:
  Init_Vcustatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Vcustatus_ros_fw_version header(::driver_msg::msg::Vcustatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Vcustatus_ros_fw_version(msg_);
  }

private:
  ::driver_msg::msg::Vcustatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Vcustatus>()
{
  return driver_msg::msg::builder::Init_Vcustatus_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSTATUS__BUILDER_HPP_
