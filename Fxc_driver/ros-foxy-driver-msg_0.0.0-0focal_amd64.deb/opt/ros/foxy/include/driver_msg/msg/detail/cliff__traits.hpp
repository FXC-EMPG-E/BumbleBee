// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from driver_msg:msg/Cliff.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__CLIFF__TRAITS_HPP_
#define DRIVER_MSG__MSG__DETAIL__CLIFF__TRAITS_HPP_

#include "driver_msg/msg/detail/cliff__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<driver_msg::msg::Cliff>()
{
  return "driver_msg::msg::Cliff";
}

template<>
inline const char * name<driver_msg::msg::Cliff>()
{
  return "driver_msg/msg/Cliff";
}

template<>
struct has_fixed_size<driver_msg::msg::Cliff>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<driver_msg::msg::Cliff>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<driver_msg::msg::Cliff>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRIVER_MSG__MSG__DETAIL__CLIFF__TRAITS_HPP_
