// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Lifter.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__LIFTER__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__LIFTER__BUILDER_HPP_

#include "driver_msg/msg/detail/lifter__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Lifter_rpm
{
public:
  explicit Init_Lifter_rpm(::driver_msg::msg::Lifter & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Lifter rpm(::driver_msg::msg::Lifter::_rpm_type arg)
  {
    msg_.rpm = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Lifter msg_;
};

class Init_Lifter_position
{
public:
  explicit Init_Lifter_position(::driver_msg::msg::Lifter & msg)
  : msg_(msg)
  {}
  Init_Lifter_rpm position(::driver_msg::msg::Lifter::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_Lifter_rpm(msg_);
  }

private:
  ::driver_msg::msg::Lifter msg_;
};

class Init_Lifter_header
{
public:
  Init_Lifter_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Lifter_position header(::driver_msg::msg::Lifter::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Lifter_position(msg_);
  }

private:
  ::driver_msg::msg::Lifter msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Lifter>()
{
  return driver_msg::msg::builder::Init_Lifter_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__LIFTER__BUILDER_HPP_
