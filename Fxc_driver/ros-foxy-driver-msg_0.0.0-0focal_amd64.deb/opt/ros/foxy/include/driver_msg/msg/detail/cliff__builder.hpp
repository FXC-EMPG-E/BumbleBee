// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Cliff.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__CLIFF__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__CLIFF__BUILDER_HPP_

#include "driver_msg/msg/detail/cliff__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Cliff_right
{
public:
  explicit Init_Cliff_right(::driver_msg::msg::Cliff & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Cliff right(::driver_msg::msg::Cliff::_right_type arg)
  {
    msg_.right = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Cliff msg_;
};

class Init_Cliff_left
{
public:
  explicit Init_Cliff_left(::driver_msg::msg::Cliff & msg)
  : msg_(msg)
  {}
  Init_Cliff_right left(::driver_msg::msg::Cliff::_left_type arg)
  {
    msg_.left = std::move(arg);
    return Init_Cliff_right(msg_);
  }

private:
  ::driver_msg::msg::Cliff msg_;
};

class Init_Cliff_header
{
public:
  Init_Cliff_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Cliff_left header(::driver_msg::msg::Cliff::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Cliff_left(msg_);
  }

private:
  ::driver_msg::msg::Cliff msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Cliff>()
{
  return driver_msg::msg::builder::Init_Cliff_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__CLIFF__BUILDER_HPP_
