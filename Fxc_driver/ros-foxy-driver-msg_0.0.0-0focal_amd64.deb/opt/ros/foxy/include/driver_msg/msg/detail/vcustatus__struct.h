// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from driver_msg:msg/Vcustatus.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_H_
#define DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'ros_fw_version'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/Vcustatus in the package driver_msg.
typedef struct driver_msg__msg__Vcustatus
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String ros_fw_version;
  bool mainboradcnntstats;
  bool motorcnntstats;
  bool safetycnntstats;
  bool liftercnntstats;
  bool automode;
  bool releasemotor;
  bool isestop;
  bool btnreset;
  bool btnestop;
  bool btnpower;
  bool btnholdtorun;
} driver_msg__msg__Vcustatus;

// Struct for a sequence of driver_msg__msg__Vcustatus.
typedef struct driver_msg__msg__Vcustatus__Sequence
{
  driver_msg__msg__Vcustatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} driver_msg__msg__Vcustatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_H_
