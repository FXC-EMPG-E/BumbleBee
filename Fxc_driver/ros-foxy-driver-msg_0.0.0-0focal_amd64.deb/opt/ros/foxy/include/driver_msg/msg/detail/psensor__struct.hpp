// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from driver_msg:msg/Psensor.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__PSENSOR__STRUCT_HPP_
#define DRIVER_MSG__MSG__DETAIL__PSENSOR__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__driver_msg__msg__Psensor __attribute__((deprecated))
#else
# define DEPRECATED__driver_msg__msg__Psensor __declspec(deprecated)
#endif

namespace driver_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Psensor_
{
  using Type = Psensor_<ContainerAllocator>;

  explicit Psensor_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front1 = 0;
      this->front2 = 0;
      this->front3 = 0;
      this->front4 = 0;
      this->front5 = 0;
      this->back1 = 0;
      this->back2 = 0;
      this->back3 = 0;
      this->back4 = 0;
      this->back5 = 0;
      this->left1 = 0;
      this->left2 = 0;
      this->left3 = 0;
      this->left4 = 0;
      this->right1 = 0;
      this->right2 = 0;
      this->right3 = 0;
      this->right4 = 0;
    }
  }

  explicit Psensor_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front1 = 0;
      this->front2 = 0;
      this->front3 = 0;
      this->front4 = 0;
      this->front5 = 0;
      this->back1 = 0;
      this->back2 = 0;
      this->back3 = 0;
      this->back4 = 0;
      this->back5 = 0;
      this->left1 = 0;
      this->left2 = 0;
      this->left3 = 0;
      this->left4 = 0;
      this->right1 = 0;
      this->right2 = 0;
      this->right3 = 0;
      this->right4 = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _front1_type =
    int16_t;
  _front1_type front1;
  using _front2_type =
    int16_t;
  _front2_type front2;
  using _front3_type =
    int16_t;
  _front3_type front3;
  using _front4_type =
    int16_t;
  _front4_type front4;
  using _front5_type =
    int16_t;
  _front5_type front5;
  using _back1_type =
    int16_t;
  _back1_type back1;
  using _back2_type =
    int16_t;
  _back2_type back2;
  using _back3_type =
    int16_t;
  _back3_type back3;
  using _back4_type =
    int16_t;
  _back4_type back4;
  using _back5_type =
    int16_t;
  _back5_type back5;
  using _left1_type =
    int16_t;
  _left1_type left1;
  using _left2_type =
    int16_t;
  _left2_type left2;
  using _left3_type =
    int16_t;
  _left3_type left3;
  using _left4_type =
    int16_t;
  _left4_type left4;
  using _right1_type =
    int16_t;
  _right1_type right1;
  using _right2_type =
    int16_t;
  _right2_type right2;
  using _right3_type =
    int16_t;
  _right3_type right3;
  using _right4_type =
    int16_t;
  _right4_type right4;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__front1(
    const int16_t & _arg)
  {
    this->front1 = _arg;
    return *this;
  }
  Type & set__front2(
    const int16_t & _arg)
  {
    this->front2 = _arg;
    return *this;
  }
  Type & set__front3(
    const int16_t & _arg)
  {
    this->front3 = _arg;
    return *this;
  }
  Type & set__front4(
    const int16_t & _arg)
  {
    this->front4 = _arg;
    return *this;
  }
  Type & set__front5(
    const int16_t & _arg)
  {
    this->front5 = _arg;
    return *this;
  }
  Type & set__back1(
    const int16_t & _arg)
  {
    this->back1 = _arg;
    return *this;
  }
  Type & set__back2(
    const int16_t & _arg)
  {
    this->back2 = _arg;
    return *this;
  }
  Type & set__back3(
    const int16_t & _arg)
  {
    this->back3 = _arg;
    return *this;
  }
  Type & set__back4(
    const int16_t & _arg)
  {
    this->back4 = _arg;
    return *this;
  }
  Type & set__back5(
    const int16_t & _arg)
  {
    this->back5 = _arg;
    return *this;
  }
  Type & set__left1(
    const int16_t & _arg)
  {
    this->left1 = _arg;
    return *this;
  }
  Type & set__left2(
    const int16_t & _arg)
  {
    this->left2 = _arg;
    return *this;
  }
  Type & set__left3(
    const int16_t & _arg)
  {
    this->left3 = _arg;
    return *this;
  }
  Type & set__left4(
    const int16_t & _arg)
  {
    this->left4 = _arg;
    return *this;
  }
  Type & set__right1(
    const int16_t & _arg)
  {
    this->right1 = _arg;
    return *this;
  }
  Type & set__right2(
    const int16_t & _arg)
  {
    this->right2 = _arg;
    return *this;
  }
  Type & set__right3(
    const int16_t & _arg)
  {
    this->right3 = _arg;
    return *this;
  }
  Type & set__right4(
    const int16_t & _arg)
  {
    this->right4 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    driver_msg::msg::Psensor_<ContainerAllocator> *;
  using ConstRawPtr =
    const driver_msg::msg::Psensor_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<driver_msg::msg::Psensor_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<driver_msg::msg::Psensor_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Psensor_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Psensor_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Psensor_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Psensor_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<driver_msg::msg::Psensor_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<driver_msg::msg::Psensor_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__driver_msg__msg__Psensor
    std::shared_ptr<driver_msg::msg::Psensor_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__driver_msg__msg__Psensor
    std::shared_ptr<driver_msg::msg::Psensor_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Psensor_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->front1 != other.front1) {
      return false;
    }
    if (this->front2 != other.front2) {
      return false;
    }
    if (this->front3 != other.front3) {
      return false;
    }
    if (this->front4 != other.front4) {
      return false;
    }
    if (this->front5 != other.front5) {
      return false;
    }
    if (this->back1 != other.back1) {
      return false;
    }
    if (this->back2 != other.back2) {
      return false;
    }
    if (this->back3 != other.back3) {
      return false;
    }
    if (this->back4 != other.back4) {
      return false;
    }
    if (this->back5 != other.back5) {
      return false;
    }
    if (this->left1 != other.left1) {
      return false;
    }
    if (this->left2 != other.left2) {
      return false;
    }
    if (this->left3 != other.left3) {
      return false;
    }
    if (this->left4 != other.left4) {
      return false;
    }
    if (this->right1 != other.right1) {
      return false;
    }
    if (this->right2 != other.right2) {
      return false;
    }
    if (this->right3 != other.right3) {
      return false;
    }
    if (this->right4 != other.right4) {
      return false;
    }
    return true;
  }
  bool operator!=(const Psensor_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Psensor_

// alias to use template instance with default allocator
using Psensor =
  driver_msg::msg::Psensor_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__PSENSOR__STRUCT_HPP_
