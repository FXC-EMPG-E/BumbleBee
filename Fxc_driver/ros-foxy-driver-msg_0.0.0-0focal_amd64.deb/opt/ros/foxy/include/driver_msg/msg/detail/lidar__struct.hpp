// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from driver_msg:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__LIDAR__STRUCT_HPP_
#define DRIVER_MSG__MSG__DETAIL__LIDAR__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__driver_msg__msg__Lidar __attribute__((deprecated))
#else
# define DEPRECATED__driver_msg__msg__Lidar __declspec(deprecated)
#endif

namespace driver_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Lidar_
{
  using Type = Lidar_<ContainerAllocator>;

  explicit Lidar_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_field = "";
      this->front_redzone = false;
      this->front_yellowzone = false;
      this->rear_field = "";
      this->rear_redzone = false;
      this->rear_yellowzone = false;
    }
  }

  explicit Lidar_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    front_field(_alloc),
    rear_field(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_field = "";
      this->front_redzone = false;
      this->front_yellowzone = false;
      this->rear_field = "";
      this->rear_redzone = false;
      this->rear_yellowzone = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _front_field_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _front_field_type front_field;
  using _front_redzone_type =
    bool;
  _front_redzone_type front_redzone;
  using _front_yellowzone_type =
    bool;
  _front_yellowzone_type front_yellowzone;
  using _rear_field_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _rear_field_type rear_field;
  using _rear_redzone_type =
    bool;
  _rear_redzone_type rear_redzone;
  using _rear_yellowzone_type =
    bool;
  _rear_yellowzone_type rear_yellowzone;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__front_field(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->front_field = _arg;
    return *this;
  }
  Type & set__front_redzone(
    const bool & _arg)
  {
    this->front_redzone = _arg;
    return *this;
  }
  Type & set__front_yellowzone(
    const bool & _arg)
  {
    this->front_yellowzone = _arg;
    return *this;
  }
  Type & set__rear_field(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->rear_field = _arg;
    return *this;
  }
  Type & set__rear_redzone(
    const bool & _arg)
  {
    this->rear_redzone = _arg;
    return *this;
  }
  Type & set__rear_yellowzone(
    const bool & _arg)
  {
    this->rear_yellowzone = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    driver_msg::msg::Lidar_<ContainerAllocator> *;
  using ConstRawPtr =
    const driver_msg::msg::Lidar_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<driver_msg::msg::Lidar_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<driver_msg::msg::Lidar_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Lidar_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Lidar_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Lidar_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Lidar_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<driver_msg::msg::Lidar_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<driver_msg::msg::Lidar_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__driver_msg__msg__Lidar
    std::shared_ptr<driver_msg::msg::Lidar_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__driver_msg__msg__Lidar
    std::shared_ptr<driver_msg::msg::Lidar_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Lidar_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->front_field != other.front_field) {
      return false;
    }
    if (this->front_redzone != other.front_redzone) {
      return false;
    }
    if (this->front_yellowzone != other.front_yellowzone) {
      return false;
    }
    if (this->rear_field != other.rear_field) {
      return false;
    }
    if (this->rear_redzone != other.rear_redzone) {
      return false;
    }
    if (this->rear_yellowzone != other.rear_yellowzone) {
      return false;
    }
    return true;
  }
  bool operator!=(const Lidar_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Lidar_

// alias to use template instance with default allocator
using Lidar =
  driver_msg::msg::Lidar_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__LIDAR__STRUCT_HPP_
