// generated from rosidl_generator_c/resource/idl.h.em
// with input from driver_msg:msg/Psensor.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__PSENSOR_H_
#define DRIVER_MSG__MSG__PSENSOR_H_

#include "driver_msg/msg/detail/psensor__struct.h"
#include "driver_msg/msg/detail/psensor__functions.h"
#include "driver_msg/msg/detail/psensor__type_support.h"

#endif  // DRIVER_MSG__MSG__PSENSOR_H_
