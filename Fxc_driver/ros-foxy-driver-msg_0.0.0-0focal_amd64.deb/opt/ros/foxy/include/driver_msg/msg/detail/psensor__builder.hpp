// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Psensor.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__PSENSOR__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__PSENSOR__BUILDER_HPP_

#include "driver_msg/msg/detail/psensor__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Psensor_right4
{
public:
  explicit Init_Psensor_right4(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Psensor right4(::driver_msg::msg::Psensor::_right4_type arg)
  {
    msg_.right4 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_right3
{
public:
  explicit Init_Psensor_right3(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_right4 right3(::driver_msg::msg::Psensor::_right3_type arg)
  {
    msg_.right3 = std::move(arg);
    return Init_Psensor_right4(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_right2
{
public:
  explicit Init_Psensor_right2(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_right3 right2(::driver_msg::msg::Psensor::_right2_type arg)
  {
    msg_.right2 = std::move(arg);
    return Init_Psensor_right3(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_right1
{
public:
  explicit Init_Psensor_right1(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_right2 right1(::driver_msg::msg::Psensor::_right1_type arg)
  {
    msg_.right1 = std::move(arg);
    return Init_Psensor_right2(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_left4
{
public:
  explicit Init_Psensor_left4(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_right1 left4(::driver_msg::msg::Psensor::_left4_type arg)
  {
    msg_.left4 = std::move(arg);
    return Init_Psensor_right1(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_left3
{
public:
  explicit Init_Psensor_left3(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_left4 left3(::driver_msg::msg::Psensor::_left3_type arg)
  {
    msg_.left3 = std::move(arg);
    return Init_Psensor_left4(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_left2
{
public:
  explicit Init_Psensor_left2(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_left3 left2(::driver_msg::msg::Psensor::_left2_type arg)
  {
    msg_.left2 = std::move(arg);
    return Init_Psensor_left3(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_left1
{
public:
  explicit Init_Psensor_left1(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_left2 left1(::driver_msg::msg::Psensor::_left1_type arg)
  {
    msg_.left1 = std::move(arg);
    return Init_Psensor_left2(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_back5
{
public:
  explicit Init_Psensor_back5(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_left1 back5(::driver_msg::msg::Psensor::_back5_type arg)
  {
    msg_.back5 = std::move(arg);
    return Init_Psensor_left1(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_back4
{
public:
  explicit Init_Psensor_back4(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_back5 back4(::driver_msg::msg::Psensor::_back4_type arg)
  {
    msg_.back4 = std::move(arg);
    return Init_Psensor_back5(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_back3
{
public:
  explicit Init_Psensor_back3(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_back4 back3(::driver_msg::msg::Psensor::_back3_type arg)
  {
    msg_.back3 = std::move(arg);
    return Init_Psensor_back4(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_back2
{
public:
  explicit Init_Psensor_back2(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_back3 back2(::driver_msg::msg::Psensor::_back2_type arg)
  {
    msg_.back2 = std::move(arg);
    return Init_Psensor_back3(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_back1
{
public:
  explicit Init_Psensor_back1(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_back2 back1(::driver_msg::msg::Psensor::_back1_type arg)
  {
    msg_.back1 = std::move(arg);
    return Init_Psensor_back2(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_front5
{
public:
  explicit Init_Psensor_front5(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_back1 front5(::driver_msg::msg::Psensor::_front5_type arg)
  {
    msg_.front5 = std::move(arg);
    return Init_Psensor_back1(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_front4
{
public:
  explicit Init_Psensor_front4(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_front5 front4(::driver_msg::msg::Psensor::_front4_type arg)
  {
    msg_.front4 = std::move(arg);
    return Init_Psensor_front5(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_front3
{
public:
  explicit Init_Psensor_front3(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_front4 front3(::driver_msg::msg::Psensor::_front3_type arg)
  {
    msg_.front3 = std::move(arg);
    return Init_Psensor_front4(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_front2
{
public:
  explicit Init_Psensor_front2(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_front3 front2(::driver_msg::msg::Psensor::_front2_type arg)
  {
    msg_.front2 = std::move(arg);
    return Init_Psensor_front3(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_front1
{
public:
  explicit Init_Psensor_front1(::driver_msg::msg::Psensor & msg)
  : msg_(msg)
  {}
  Init_Psensor_front2 front1(::driver_msg::msg::Psensor::_front1_type arg)
  {
    msg_.front1 = std::move(arg);
    return Init_Psensor_front2(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

class Init_Psensor_header
{
public:
  Init_Psensor_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Psensor_front1 header(::driver_msg::msg::Psensor::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Psensor_front1(msg_);
  }

private:
  ::driver_msg::msg::Psensor msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Psensor>()
{
  return driver_msg::msg::builder::Init_Psensor_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__PSENSOR__BUILDER_HPP_
