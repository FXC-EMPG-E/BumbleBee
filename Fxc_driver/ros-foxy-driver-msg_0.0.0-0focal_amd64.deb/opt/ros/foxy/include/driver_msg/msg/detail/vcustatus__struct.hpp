// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from driver_msg:msg/Vcustatus.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_HPP_
#define DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__driver_msg__msg__Vcustatus __attribute__((deprecated))
#else
# define DEPRECATED__driver_msg__msg__Vcustatus __declspec(deprecated)
#endif

namespace driver_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Vcustatus_
{
  using Type = Vcustatus_<ContainerAllocator>;

  explicit Vcustatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ros_fw_version = "";
      this->mainboradcnntstats = false;
      this->motorcnntstats = false;
      this->safetycnntstats = false;
      this->liftercnntstats = false;
      this->automode = false;
      this->releasemotor = false;
      this->isestop = false;
      this->btnreset = false;
      this->btnestop = false;
      this->btnpower = false;
      this->btnholdtorun = false;
    }
  }

  explicit Vcustatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    ros_fw_version(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ros_fw_version = "";
      this->mainboradcnntstats = false;
      this->motorcnntstats = false;
      this->safetycnntstats = false;
      this->liftercnntstats = false;
      this->automode = false;
      this->releasemotor = false;
      this->isestop = false;
      this->btnreset = false;
      this->btnestop = false;
      this->btnpower = false;
      this->btnholdtorun = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _ros_fw_version_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _ros_fw_version_type ros_fw_version;
  using _mainboradcnntstats_type =
    bool;
  _mainboradcnntstats_type mainboradcnntstats;
  using _motorcnntstats_type =
    bool;
  _motorcnntstats_type motorcnntstats;
  using _safetycnntstats_type =
    bool;
  _safetycnntstats_type safetycnntstats;
  using _liftercnntstats_type =
    bool;
  _liftercnntstats_type liftercnntstats;
  using _automode_type =
    bool;
  _automode_type automode;
  using _releasemotor_type =
    bool;
  _releasemotor_type releasemotor;
  using _isestop_type =
    bool;
  _isestop_type isestop;
  using _btnreset_type =
    bool;
  _btnreset_type btnreset;
  using _btnestop_type =
    bool;
  _btnestop_type btnestop;
  using _btnpower_type =
    bool;
  _btnpower_type btnpower;
  using _btnholdtorun_type =
    bool;
  _btnholdtorun_type btnholdtorun;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__ros_fw_version(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->ros_fw_version = _arg;
    return *this;
  }
  Type & set__mainboradcnntstats(
    const bool & _arg)
  {
    this->mainboradcnntstats = _arg;
    return *this;
  }
  Type & set__motorcnntstats(
    const bool & _arg)
  {
    this->motorcnntstats = _arg;
    return *this;
  }
  Type & set__safetycnntstats(
    const bool & _arg)
  {
    this->safetycnntstats = _arg;
    return *this;
  }
  Type & set__liftercnntstats(
    const bool & _arg)
  {
    this->liftercnntstats = _arg;
    return *this;
  }
  Type & set__automode(
    const bool & _arg)
  {
    this->automode = _arg;
    return *this;
  }
  Type & set__releasemotor(
    const bool & _arg)
  {
    this->releasemotor = _arg;
    return *this;
  }
  Type & set__isestop(
    const bool & _arg)
  {
    this->isestop = _arg;
    return *this;
  }
  Type & set__btnreset(
    const bool & _arg)
  {
    this->btnreset = _arg;
    return *this;
  }
  Type & set__btnestop(
    const bool & _arg)
  {
    this->btnestop = _arg;
    return *this;
  }
  Type & set__btnpower(
    const bool & _arg)
  {
    this->btnpower = _arg;
    return *this;
  }
  Type & set__btnholdtorun(
    const bool & _arg)
  {
    this->btnholdtorun = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    driver_msg::msg::Vcustatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const driver_msg::msg::Vcustatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Vcustatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      driver_msg::msg::Vcustatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__driver_msg__msg__Vcustatus
    std::shared_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__driver_msg__msg__Vcustatus
    std::shared_ptr<driver_msg::msg::Vcustatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Vcustatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->ros_fw_version != other.ros_fw_version) {
      return false;
    }
    if (this->mainboradcnntstats != other.mainboradcnntstats) {
      return false;
    }
    if (this->motorcnntstats != other.motorcnntstats) {
      return false;
    }
    if (this->safetycnntstats != other.safetycnntstats) {
      return false;
    }
    if (this->liftercnntstats != other.liftercnntstats) {
      return false;
    }
    if (this->automode != other.automode) {
      return false;
    }
    if (this->releasemotor != other.releasemotor) {
      return false;
    }
    if (this->isestop != other.isestop) {
      return false;
    }
    if (this->btnreset != other.btnreset) {
      return false;
    }
    if (this->btnestop != other.btnestop) {
      return false;
    }
    if (this->btnpower != other.btnpower) {
      return false;
    }
    if (this->btnholdtorun != other.btnholdtorun) {
      return false;
    }
    return true;
  }
  bool operator!=(const Vcustatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Vcustatus_

// alias to use template instance with default allocator
using Vcustatus =
  driver_msg::msg::Vcustatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSTATUS__STRUCT_HPP_
