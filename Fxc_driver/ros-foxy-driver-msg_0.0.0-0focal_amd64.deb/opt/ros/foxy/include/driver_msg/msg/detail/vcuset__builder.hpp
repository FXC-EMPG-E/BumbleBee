// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from driver_msg:msg/Vcuset.idl
// generated code does not contain a copyright notice

#ifndef DRIVER_MSG__MSG__DETAIL__VCUSET__BUILDER_HPP_
#define DRIVER_MSG__MSG__DETAIL__VCUSET__BUILDER_HPP_

#include "driver_msg/msg/detail/vcuset__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace driver_msg
{

namespace msg
{

namespace builder
{

class Init_Vcuset_poweroff_roscube
{
public:
  explicit Init_Vcuset_poweroff_roscube(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  ::driver_msg::msg::Vcuset poweroff_roscube(::driver_msg::msg::Vcuset::_poweroff_roscube_type arg)
  {
    msg_.poweroff_roscube = std::move(arg);
    return std::move(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_enable_safety_zone
{
public:
  explicit Init_Vcuset_enable_safety_zone(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_poweroff_roscube enable_safety_zone(::driver_msg::msg::Vcuset::_enable_safety_zone_type arg)
  {
    msg_.enable_safety_zone = std::move(arg);
    return Init_Vcuset_poweroff_roscube(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_lighting
{
public:
  explicit Init_Vcuset_lighting(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_enable_safety_zone lighting(::driver_msg::msg::Vcuset::_lighting_type arg)
  {
    msg_.lighting = std::move(arg);
    return Init_Vcuset_enable_safety_zone(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_reset_lifter
{
public:
  explicit Init_Vcuset_reset_lifter(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_lighting reset_lifter(::driver_msg::msg::Vcuset::_reset_lifter_type arg)
  {
    msg_.reset_lifter = std::move(arg);
    return Init_Vcuset_lighting(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_reset_odom
{
public:
  explicit Init_Vcuset_reset_odom(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_reset_lifter reset_odom(::driver_msg::msg::Vcuset::_reset_odom_type arg)
  {
    msg_.reset_odom = std::move(arg);
    return Init_Vcuset_reset_lifter(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_reset_imu
{
public:
  explicit Init_Vcuset_reset_imu(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_reset_odom reset_imu(::driver_msg::msg::Vcuset::_reset_imu_type arg)
  {
    msg_.reset_imu = std::move(arg);
    return Init_Vcuset_reset_odom(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_sleep_mcu
{
public:
  explicit Init_Vcuset_sleep_mcu(::driver_msg::msg::Vcuset & msg)
  : msg_(msg)
  {}
  Init_Vcuset_reset_imu sleep_mcu(::driver_msg::msg::Vcuset::_sleep_mcu_type arg)
  {
    msg_.sleep_mcu = std::move(arg);
    return Init_Vcuset_reset_imu(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

class Init_Vcuset_header
{
public:
  Init_Vcuset_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Vcuset_sleep_mcu header(::driver_msg::msg::Vcuset::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Vcuset_sleep_mcu(msg_);
  }

private:
  ::driver_msg::msg::Vcuset msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::driver_msg::msg::Vcuset>()
{
  return driver_msg::msg::builder::Init_Vcuset_header();
}

}  // namespace driver_msg

#endif  // DRIVER_MSG__MSG__DETAIL__VCUSET__BUILDER_HPP_
